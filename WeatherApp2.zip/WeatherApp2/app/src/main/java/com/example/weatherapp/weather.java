package com.example.weatherapp;

import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link WeatherFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class WeatherFragment extends Fragment {

    public Spinner citySpinner; // A Spinner to select a city
    public Button selectCityButton;


    // Fragment initialization parameters
    static final String ARG_PARAM1 = "param1";
    static final String ARG_PARAM2 = "param2";

    String mParam1;
    String mParam2;

    public WeatherFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment WeatherFragment.
     */
    public static WeatherFragment newInstance(String param1, String param2) {
        WeatherFragment fragment = new WeatherFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_city__selection, container, false);

        citySpinner = view.findViewById(R.id.spinner_city);
        selectCityButton = view.findViewById(R.id.button2);

        // Setup the Spinner (assuming cities array or list is available)
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(
                getContext(),
                android.R.layout.simple_spinner_item,
                new String[]{"New York", "Los Angeles", "Chicago", "Miami", "San Francisco"}
        );
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citySpinner.setAdapter(cityAdapter);

        selectCityButton.setOnClickListener(v -> {
            String selectedCity = citySpinner.getSelectedItem().toString();

            // Navigate to WeatherFragment with the selected city
            WeatherFragment weatherFragment = WeatherFragment.newInstance(selectedCity, null);
            ((MainActivity) requireActivity()).navigateToFragment(weatherFragment, "WeatherFragment");
        });

        return view;
    }
}


