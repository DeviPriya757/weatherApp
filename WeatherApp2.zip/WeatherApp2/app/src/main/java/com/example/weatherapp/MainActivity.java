package com.example.weatherapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            loadInitialFragment();
        }
    }

    // Load the initial fragment (CitySelectionFragment)
    public void loadInitialFragment() {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragmentContainerView3, new city_selection(), "CitySelectionFragment")
                .commit();
    }

    // Navigate to a new fragment and add it to the back stack
    public void navigateToFragment(Fragment fragment, String tag) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainerView3, fragment, tag)
                .addToBackStack(tag) // Adds to the back stack for default back navigation
                .commit();
    }
}
